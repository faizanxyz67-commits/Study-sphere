# Study Sphere — expanded starter prototype

A mobile-first, responsive learning-platform prototype for JKBOSE Classes 9 and 10, inspired by common online-learning app patterns. This is an independent project and is not affiliated with PW/Physics Wallah or JKBOSE.

## Features in this prototype
- Dashboard and course catalogue
- Class 9 and Class 10 sample chapter resources
- Digital library filters
- Sample revision notes
- Interactive MCQs with explanations and scores
- Practice-session outlines
- Study planner / task checklist
- Bookmarks
- Local doubt notebook
- Search
- Local progress stats, quiz history, and browser storage
- Responsive mobile navigation and basic PWA/offline-cache files

## Try on Android
1. Download and extract the ZIP.
2. Open `StudySphere/index.html` in a browser to preview it.
3. For installable web-app features, upload the files to a static HTTPS host (for example GitHub Pages or Netlify), open the hosted URL in Chrome, and choose **Add to Home screen** or **Install app** if offered.
4. This package is not an APK. Creating a signed Android APK is a separate build step.

## Important limitations
- Course and notes content is starter/demo content, not the full JKBOSE syllabus.
- No video hosting, live teacher support, user accounts, admin dashboard, cloud sync, or server-side database yet.
- Local planner/bookmarks/history are stored only in the current browser on this device.
- Practice outlines are not official previous-year papers.
- Before launch, verify all content against the current syllabus and use authorised/appropriately licensed material.
